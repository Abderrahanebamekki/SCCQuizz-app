package com.example.sccquiz

import androidx.compose.runtime.mutableStateOf
import androidx.lifecycle.ViewModel

 class TypeOfQuestions (
     nq: String? = null,
     nbq: Int? = null,
     tq: Int? = null,
     rq: Float? = null ,
    img : String? = null
 ):ViewModel(){
     constructor() :this("",0 ,0,0f,"")
     var nq = mutableStateOf(nq)
     var nbq = mutableStateOf(nbq)
     var tq = mutableStateOf(tq)
     var rq = mutableStateOf(rq)
     var img = mutableStateOf(img)
 }