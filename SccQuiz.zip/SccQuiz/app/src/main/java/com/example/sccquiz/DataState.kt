package com.example.sccquiz

sealed class DataState{
    class Success(val data : MutableList<TypeOfQuestions> ) : DataState()
    class Failure(val message : String): DataState()
    object Loading : DataState()
    object Empty :DataState()
}
